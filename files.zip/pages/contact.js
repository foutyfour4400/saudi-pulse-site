import ContactForm from "../components/ContactForm"
import LanguageSwitcher from "../components/LanguageSwitcher"
import GovernmentLinks from "../components/GovernmentLinks"
import TopBanner from "../components/TopBanner"

export default function ContactPage() {
  return (
    <div>
      <div style={{ background: "#195a9a", color: "#fff", padding: "0.8rem 1.2rem 0.8rem 0.5rem" }}>
        <span style={{ fontWeight: "bold", fontSize: "1.25rem" }}>Saudi Hub</span>
        <LanguageSwitcher />
      </div>
      <TopBanner />
      <ContactForm />
      <GovernmentLinks />
      <footer>
        &copy; {new Date().getFullYear()} Saudi Hub
      </footer>
    </div>
  )
}