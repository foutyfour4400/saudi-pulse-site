import '../styles/global.css'
import '../utils/i18n'
import { useEffect } from 'react'
import { useRouter } from 'next/router'
import { appWithTranslation } from 'react-i18next'
import Head from 'next/head'

function MyApp({ Component, pageProps }) {
  const { locale } = useRouter()

  useEffect(() => {
    if (typeof window !== "undefined") {
      document.dir = locale === "ar" ? "rtl" : "ltr"
    }
  }, [locale])

  return (
    <>
      <Head>
        <title>Saudi Hub</title>
        <meta name="viewport" content="width=device-width,initial-scale=1" />
      </Head>
      <Component {...pageProps} />
    </>
  )
}

export default appWithTranslation(MyApp)