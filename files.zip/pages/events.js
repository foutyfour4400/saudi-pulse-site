import LanguageSwitcher from "../components/LanguageSwitcher"
import TopBanner from "../components/TopBanner"
import GovernmentLinks from "../components/GovernmentLinks"
import EventsSection from "../components/EventsSection"
import CitySelector from "../components/CitySelector"
import { useState } from "react"
import { useTranslation } from "react-i18next"

export default function EventsPage() {
  const [selectedCity, setSelectedCity] = useState("")
  const { t } = useTranslation()

  return (
    <main>
      <div style={{ background: "#195a9a", color: "#fff", padding: "0.8rem 1.2rem 0.8rem 0.5rem" }}>
        <span style={{ fontWeight: "bold", fontSize: "1.25rem" }}>Saudi Hub</span>
        <span style={{ marginLeft: 22 }}>
          <CitySelector city={selectedCity} />
        </span>
        <LanguageSwitcher />
      </div>
      <TopBanner />
      <div style={{ padding: "2.5rem 2rem" }}>
        <EventsSection city={selectedCity} />
      </div>
      <GovernmentLinks />
      <footer>
        &copy; {new Date().getFullYear()} Saudi Hub
      </footer>
    </main>
  )
}