export default function handler(req, res) {
  const { city } = req.query
  const allJobs = [
    { title: "Software Engineer", company: "STC", location: "Riyadh", url: "https://www.bayt.com/en/saudi-arabia/jobs/software-engineer-123/" },
    { title: "Marketing Manager", company: "Almarai", location: "Jeddah", url: "https://www.bayt.com/en/saudi-arabia/jobs/marketing-manager-456/" },
    { title: "Sales Associate", company: "Jarir Bookstore", location: "Dammam", url: "https://www.linkedin.com/jobs/view/789/" },
    { title: "Data Analyst", company: "Aramco", location: "Dhahran", url: "https://www.linkedin.com/jobs/view/1234/" },
    { title: "HR Coordinator", company: "Al Nahdi", location: "Makkah", url: "https://www.bayt.com/en/saudi-arabia/jobs/hr-coordinator-321/" }
  ]
  res.status(200).json(city ? allJobs.filter(j => j.location.toLowerCase().includes(city.toLowerCase())) : allJobs)
}