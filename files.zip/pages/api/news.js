export default function handler(req, res) {
  res.status(200).json([
    { title: "Saudi Arabia launches new giga-project in Riyadh", url: "https://www.arabnews.com/node/2500001/saudi-arabia" },
    { title: "National Day celebrations announced for all cities", url: "https://www.spa.gov.sa/2670001" },
    { title: "Qiddiya Entertainment City opening date revealed", url: "https://www.qiddiya.com/en/news" },
    { title: "Saudi stocks surge as TASI hits new high", url: "https://www.tadawul.com.sa" }
  ])
}