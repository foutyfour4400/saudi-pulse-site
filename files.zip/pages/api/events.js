export default function handler(req, res) {
  const { city } = req.query
  const allEvents = [
    { title: "Jeddah Season Concert", image: "/images/jeddahseason.jpg", url: "https://www.jeddahseason.sa/events", date: "2025-08-25", location: "Jeddah" },
    { title: "Riyadh International Book Fair", image: "/images/riyadhbookfair.jpg", url: "https://bookfair.riyadh.sa/", date: "2025-09-10", location: "Riyadh" },
    { title: "Makkah Food Festival", image: "/images/makkahfood.jpg", url: "https://www.makkah.gov.sa/events", date: "2025-09-20", location: "Makkah" }
  ]
  res.status(200).json(city ? allEvents.filter(e => e.location.toLowerCase().includes(city.toLowerCase())) : allEvents)
}