export default function handler(req, res) {
  const { city } = req.query
  const allPromos = [
    { title: "Mall of Arabia Summer Sale", image: "/images/mallarabia.jpg", url: "https://mallarabia.com.sa/promos", date: "2025-09-01", location: "Jeddah" },
    { title: "Qiddiya City Pre-Opening", image: "/images/qiddiya.jpg", url: "https://www.qiddiya.com/en/news", date: "2025-10-10", location: "Riyadh" },
    { title: "Riyadh Park Grand Offers", image: "/images/riyadhpark.jpg", url: "https://riyadhpark.com/offers", date: "", location: "Riyadh" }
  ]
  res.status(200).json(city ? allPromos.filter(p => p.location.toLowerCase().includes(city.toLowerCase())) : allPromos)
}