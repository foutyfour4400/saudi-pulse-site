export default function handler(req, res) {
  res.status(200).json({
    usd_sar: "3.75",
    eur_sar: "4.10",
    tasi: "12100"
  })
}