import LanguageSwitcher from "../components/LanguageSwitcher"
import TopBanner from "../components/TopBanner"
import NewsTicker from "../components/NewsTicker"
import CitySelector from "../components/CitySelector"
import JobSection from "../components/JobSection"
import PromotionsSection from "../components/PromotionsSection"
import EventsSection from "../components/EventsSection"
import GovernmentLinks from "../components/GovernmentLinks"
import { useRouter } from "next/router"
import { useState } from "react"
import { useTranslation } from "react-i18next"

export default function Home() {
  const [selectedCity, setSelectedCity] = useState("")
  const router = useRouter()
  const { t } = useTranslation()

  // update city from url param if needed

  return (
    <main>
      <div style={{ background: "#195a9a", color: "#fff", padding: "0.8rem 1.2rem 0.8rem 0.5rem" }}>
        <span style={{ fontWeight: "bold", fontSize: "1.25rem" }}>Saudi Hub</span>
        <span style={{ marginLeft: 22 }}>
          <CitySelector city={selectedCity} />
        </span>
        <LanguageSwitcher />
      </div>
      <TopBanner />
      <div style={{ background: "#fff", padding: "0.7rem 0 0.7rem 2rem", borderBottom: "1px solid #f0f3f5" }}>
        <nav>
          <a href="/" style={{ marginRight: 24 }}>{t("home")}</a>
          <a href="/jobs" style={{ marginRight: 24 }}>{t("jobs")}</a>
          <a href="/offers" style={{ marginRight: 24 }}>{t("promotions")}</a>
          <a href="/events" style={{ marginRight: 24 }}>{t("events")}</a>
          <a href="/contact">{t("contact_us")}</a>
        </nav>
      </div>
      <div className="main-content">
        <div style={{ flex: 1, padding: "1.5rem 1rem 1rem 2rem" }}>
          <JobSection city={selectedCity} />
          <PromotionsSection city={selectedCity} />
          <EventsSection city={selectedCity} />
        </div>
        <NewsTicker />
      </div>
      <GovernmentLinks />
      <footer>
        &copy; {new Date().getFullYear()} Saudi Hub
      </footer>
    </main>
  )
}