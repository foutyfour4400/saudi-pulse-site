import React, { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

export default function PromotionsSection({ city }) {
  const [promos, setPromos] = useState([])
  const { t } = useTranslation()

  useEffect(() => {
    fetch(`/api/promotions?city=${city || ""}`)
      .then(res => res.json())
      .then(setPromos)
  }, [city])

  return (
    <section>
      <h2>{t("promotions")}</h2>
      <ul>
        {promos.map((promo, idx) => (
          <li key={idx} style={{ marginBottom: "1.5rem" }}>
            <img src={promo.image} alt={promo.title} style={{ width: "120px", borderRadius: 7, marginRight: 12 }} />
            <a href={promo.url} target="_blank" rel="noopener noreferrer">
              <b>{promo.title}</b>
            </a>
            <div>
              {promo.date ? `Opens: ${promo.date}` : null}
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}