import React from "react"
import { useTranslation } from "react-i18next"

export default function LanguageSwitcher() {
  const { i18n } = useTranslation()
  const changeLanguage = lng => {
    i18n.changeLanguage(lng)
    document.dir = lng === "ar" ? "rtl" : "ltr"
  }
  return (
    <div style={{ float: "right", margin: "0.7rem 1rem 0 0" }}>
      <button onClick={() => changeLanguage("en")}>English</button>
      <button onClick={() => changeLanguage("ar")}>العربية</button>
    </div>
  )
}