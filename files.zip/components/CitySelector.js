import React from "react"
import { useRouter } from "next/router"
import { useTranslation } from "react-i18next"

const cities = [
  { name: "Riyadh", slug: "riyadh" },
  { name: "Jeddah", slug: "jeddah" },
  { name: "Dammam", slug: "dammam" },
  { name: "Makkah", slug: "makkah" },
  { name: "Al Khobar", slug: "alkhobar" }
]

export default function CitySelector({ city }) {
  const router = useRouter()
  const { t } = useTranslation()

  return (
    <select
      value={city}
      onChange={e => router.push(e.target.value === "" ? "/" : `/city/${e.target.value}`)}
      aria-label={t("choose_city")}
    >
      <option value="">{t("choose_city")}</option>
      {cities.map(c => (
        <option key={c.slug} value={c.slug}>
          {c.name}
        </option>
      ))}
    </select>
  )
}