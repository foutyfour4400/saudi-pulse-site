import React from "react"
import { useTranslation } from "react-i18next"

const govLinks = [
  { name: "Absher", url: "https://www.absher.sa", img: "/images/absher.png" },
  { name: "Tawakkalna", url: "https://ta.sdaia.gov.sa", img: "/images/tawakkalna.png" },
  { name: "Mudad", url: "https://mudad.com.sa", img: "/images/mudad.png" },
  { name: "Sehhaty", url: "https://www.sehhaty.sa", img: "/images/sehhaty.png" }
]

export default function GovernmentLinks() {
  const { t } = useTranslation()
  return (
    <div style={{ background: "#f6f6f6", padding: "1.2rem 0", borderTop: "1px solid #e6ebf2" }}>
      <h4 style={{ margin: "0 0 0.7rem 0", textAlign: "center" }}>{t("government_services")}</h4>
      <ul style={{ display: "flex", justifyContent: "center", gap: "2.5rem", listStyle: "none", margin: 0, padding: 0 }}>
        {govLinks.map(link => (
          <li key={link.url}>
            <a href={link.url} target="_blank" rel="noopener noreferrer">
              <img src={link.img} alt={link.name} style={{ width: "40px", display: "block", margin: "0 auto" }} />
              <div style={{ fontSize: "0.93rem", marginTop: 4, textAlign: "center" }}>{link.name}</div>
            </a>
          </li>
        ))}
      </ul>
    </div>
  )
}