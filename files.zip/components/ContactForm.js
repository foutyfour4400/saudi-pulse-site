import React, { useState } from "react"
import { useTranslation } from "react-i18next"

export default function ContactForm() {
  const [form, setForm] = useState({ email: "", phone: "", description: "", file: null })
  const [sent, setSent] = useState(false)
  const { t } = useTranslation()

  const handleChange = e => {
    const { name, value, files } = e.target
    setForm(f => ({ ...f, [name]: files ? files[0] : value }))
  }

  const handleSubmit = e => {
    e.preventDefault()
    setSent(true)
    setTimeout(() => setSent(false), 2500)
    setForm({ email: "", phone: "", description: "", file: null })
    // For real use, send data to backend/email here
  }

  return (
    <form onSubmit={handleSubmit}>
      <h1>{t("contact_us")}</h1>
      <input
        name="email"
        type="email"
        placeholder={t("your_email")}
        required
        value={form.email}
        onChange={handleChange}
      />
      <input
        name="phone"
        type="tel"
        placeholder={t("contact_number")}
        required
        value={form.phone}
        onChange={handleChange}
      />
      <textarea
        name="description"
        placeholder={t("description")}
        required
        value={form.description}
        onChange={handleChange}
        rows={4}
      />
      <input
        name="file"
        type="file"
        accept="image/*"
        onChange={handleChange}
      />
      <button type="submit">{t("send")}</button>
      {sent && <div style={{ color: "green", marginTop: 14 }}>{t("thank_you")}</div>}
    </form>
  )
}