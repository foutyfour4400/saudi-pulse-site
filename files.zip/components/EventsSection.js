import React, { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

export default function EventsSection({ city }) {
  const [events, setEvents] = useState([])
  const { t } = useTranslation()

  useEffect(() => {
    fetch(`/api/events?city=${city || ""}`)
      .then(res => res.json())
      .then(setEvents)
  }, [city])

  return (
    <section>
      <h2>{t("events")}</h2>
      <ul>
        {events.map((event, idx) => (
          <li key={idx} style={{ marginBottom: "1.5rem" }}>
            <img src={event.image} alt={event.title} style={{ width: "120px", borderRadius: 7, marginRight: 12 }} />
            <a href={event.url} target="_blank" rel="noopener noreferrer">
              <b>{event.title}</b>
            </a>
            <div>
              {event.date}
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}