import React, { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

export default function NewsTicker() {
  const [news, setNews] = useState([])
  const { t } = useTranslation()

  useEffect(() => {
    fetch("/api/news")
      .then(res => res.json())
      .then(setNews)
  }, [])

  return (
    <aside className="news-ticker">
      <h4>{t("latest_news")}</h4>
      <ul>
        {news.map((item, idx) => (
          <li key={idx}>
            <a href={item.url} target="_blank" rel="noopener noreferrer">
              {item.title}
            </a>
          </li>
        ))}
      </ul>
    </aside>
  )
}