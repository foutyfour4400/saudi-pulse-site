import React, { useEffect, useState } from "react"

export default function TopBanner() {
  const [news, setNews] = useState([])
  const [forex, setForex] = useState({ usd_sar: "3.75", eur_sar: "4.10", tasi: "12100" })

  useEffect(() => {
    fetch("/api/news")
      .then(res => res.json())
      .then(setNews)
    fetch("/api/forex")
      .then(res => res.json())
      .then(setForex)
  }, [])

  return (
    <div>
      <div className="marquee">
        <span>
          {news.map(item => item.title).join(" • ") || "Welcome to Saudi Hub"}
        </span>
      </div>
      <div className="marquee" style={{ background: "#fbeee0", color: "#d2691e" }}>
        <span>
          Market: USD/SAR {forex.usd_sar} | EUR/SAR {forex.eur_sar} | TASI {forex.tasi}
        </span>
      </div>
    </div>
  )
}