import React, { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

export default function JobSection({ city }) {
  const [jobs, setJobs] = useState([])
  const { t } = useTranslation()

  useEffect(() => {
    fetch(`/api/jobs?city=${city || ""}`)
      .then(res => res.json())
      .then(setJobs)
  }, [city])

  return (
    <section>
      <h2>{t("latest_jobs")}{city ? ` - ${city}` : ""}</h2>
      <ul>
        {jobs.map((job, idx) => (
          <li key={idx} style={{ marginBottom: "1rem" }}>
            <a href={job.url} target="_blank" rel="noopener noreferrer">
              <b>{job.title}</b>
            </a>
            <div>
              {job.company} – {job.location}
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}