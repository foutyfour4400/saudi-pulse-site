import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'

i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: {
          latest_news: "Latest News",
          latest_jobs: "Latest Jobs",
          promotions: "Promotions & Malls",
          events: "Events",
          contact_us: "Contact Us",
          choose_city: "Choose City",
          government_services: "Government Services",
          your_email: "Your Email",
          contact_number: "Contact Number",
          description: "Description",
          upload_image: "Upload Image",
          send: "Send",
          thank_you: "Thank you for contacting us!",
          home: "Home",
          jobs: "Jobs",
          offers: "Offers",
          city: "City",
          post_job: "Post a Job"
        }
      },
      ar: {
        translation: {
          latest_news: "آخر الأخبار",
          latest_jobs: "أحدث الوظائف",
          promotions: "العروض والمجمعات",
          events: "الفعاليات",
          contact_us: "اتصل بنا",
          choose_city: "اختر المدينة",
          government_services: "الخدمات الحكومية",
          your_email: "بريدك الإلكتروني",
          contact_number: "رقم الاتصال",
          description: "وصف",
          upload_image: "تحميل صورة",
          send: "إرسال",
          thank_you: "شكرًا لتواصلك معنا!",
          home: "الرئيسية",
          jobs: "وظائف",
          offers: "العروض",
          city: "المدينة",
          post_job: "أضف وظيفة"
        }
      }
    },
    lng: "en",
    fallbackLng: "en",
    interpolation: { escapeValue: false }
  })

export default i18n